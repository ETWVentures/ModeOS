import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, SafeAreaView } from 'react-native';
import { Check, BookOpen, Heart, Users, MessageCircle } from 'lucide-react-native';
import ProductivityChatbot from '@/components/ProductivityChatbot';

type Mode = 'exam' | 'health' | 'social';

interface Ritual {
  id: string;
  title: string;
  description: string;
}

const rituals: Record<Mode, Ritual[]> = {
  exam: [
    { id: 'study-session', title: 'Deep Study Session', description: '2 hours of focused study' },
    { id: 'review-notes', title: 'Review Yesterday\'s Notes', description: 'Go through previous day\'s material' },
    { id: 'practice-problems', title: 'Practice Problems', description: 'Solve 10 practice questions' },
  ],
  health: [
    { id: 'morning-workout', title: 'Morning Workout', description: '30 minutes of exercise' },
    { id: 'meditation', title: 'Meditation', description: '10 minutes of mindfulness' },
    { id: 'healthy-meal', title: 'Healthy Meal Prep', description: 'Plan and prepare nutritious meals' },
  ],
  social: [
    { id: 'call-friend', title: 'Call a Friend', description: 'Connect with someone you care about' },
    { id: 'community-activity', title: 'Community Activity', description: 'Participate in a group activity' },
    { id: 'help-someone', title: 'Help Someone', description: 'Do something kind for another person' },
  ],
};

const modeConfig = {
  exam: {
    title: 'Exam Mode',
    color: '#3b82f6',
    bgColor: '#eff6ff',
    icon: BookOpen,
  },
  health: {
    title: 'Health Mode',
    color: '#10b981',
    bgColor: '#ecfdf5',
    icon: Heart,
  },
  social: {
    title: 'Social Mode',
    color: '#f59e0b',
    bgColor: '#fffbeb',
    icon: Users,
  },
};

export default function HomeScreen() {
  const [selectedMode, setSelectedMode] = useState<Mode>('exam');
  const [completedRituals, setCompletedRituals] = useState<Record<string, boolean>>({});
  const [chatbotVisible, setChatbotVisible] = useState(false);

  const toggleRitual = (ritualId: string) => {
    setCompletedRituals(prev => ({
      ...prev,
      [ritualId]: !prev[ritualId],
    }));
  };

  const currentModeConfig = modeConfig[selectedMode];
  const currentRituals = rituals[selectedMode];
  const completedCount = currentRituals.filter(ritual => completedRituals[ritual.id]).length;

  const handleCheckin = () => {
    setChatbotVisible(true);
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>ModeOS</Text>
          <Text style={styles.headerSubtitle}>Your Daily Ritual Companion</Text>
        </View>

        {/* Mode Switcher */}
        <View style={styles.modeSwitcher}>
          {(Object.keys(modeConfig) as Mode[]).map((mode) => {
            const config = modeConfig[mode];
            const isSelected = selectedMode === mode;
            const IconComponent = config.icon;
            
            return (
              <TouchableOpacity
                key={mode}
                style={[
                  styles.modeButton,
                  isSelected && {
                    backgroundColor: config.color,
                    shadowColor: config.color,
                    shadowOffset: { width: 0, height: 4 },
                    shadowOpacity: 0.3,
                    shadowRadius: 8,
                    elevation: 8,
                  }
                ]}
                onPress={() => setSelectedMode(mode)}
                activeOpacity={0.8}
              >
                <IconComponent 
                  size={20} 
                  color={isSelected ? 'white' : config.color} 
                />
                <Text style={[
                  styles.modeButtonText,
                  { color: isSelected ? 'white' : config.color }
                ]}>
                  {config.title}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Progress Section */}
        <View style={[styles.progressCard, { backgroundColor: currentModeConfig.bgColor }]}>
          <View style={styles.progressHeader}>
            <View style={styles.progressInfo}>
              <Text style={[styles.progressTitle, { color: currentModeConfig.color }]}>
                Today's Progress
              </Text>
              <Text style={styles.progressSubtitle}>
                {completedCount} of {currentRituals.length} rituals completed
              </Text>
            </View>
            <View style={[styles.progressCircle, { borderColor: currentModeConfig.color }]}>
              <Text style={[styles.progressText, { color: currentModeConfig.color }]}>
                {completedCount}/{currentRituals.length}
              </Text>
            </View>
          </View>
          
          {/* Progress Bar */}
          <View style={styles.progressBarContainer}>
            <View 
              style={[
                styles.progressBar,
                { 
                  width: `${(completedCount / currentRituals.length) * 100}%`,
                  backgroundColor: currentModeConfig.color 
                }
              ]} 
            />
          </View>
        </View>

        {/* Check-in Button */}
        <View style={styles.checkinContainer}>
          <TouchableOpacity
            style={[styles.checkinButton, { backgroundColor: currentModeConfig.color }]}
            onPress={handleCheckin}
            activeOpacity={0.8}
          >
            <View style={styles.checkinIconContainer}>
              <MessageCircle size={24} color="white" />
            </View>
            <View style={styles.checkinTextContainer}>
              <Text style={styles.checkinTitle}>Daily Check-in</Text>
              <Text style={styles.checkinSubtitle}>
                Chat with your productivity coach
              </Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* Ritual Tracker */}
        <View style={styles.ritualSection}>
          <Text style={styles.ritualSectionTitle}>Daily Rituals</Text>
          
          {currentRituals.map((ritual) => {
            const isCompleted = completedRituals[ritual.id];
            
            return (
              <TouchableOpacity
                key={ritual.id}
                style={[
                  styles.ritualCard,
                  isCompleted && styles.ritualCardCompleted,
                ]}
                onPress={() => toggleRitual(ritual.id)}
                activeOpacity={0.7}
              >
                <View style={styles.ritualContent}>
                  <View style={styles.ritualText}>
                    <Text style={[
                      styles.ritualTitle,
                      isCompleted && styles.ritualTitleCompleted,
                    ]}>
                      {ritual.title}
                    </Text>
                    <Text style={[
                      styles.ritualDescription,
                      isCompleted && styles.ritualDescriptionCompleted,
                    ]}>
                      {ritual.description}
                    </Text>
                  </View>
                  
                  <View style={[
                    styles.checkbox,
                    isCompleted && {
                      backgroundColor: currentModeConfig.color,
                      borderColor: currentModeConfig.color,
                    }
                  ]}>
                    {isCompleted && <Check size={16} color="white" />}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Bottom Spacing */}
        <View style={styles.bottomSpacing} />
      </ScrollView>

      {/* Productivity Chatbot */}
      <ProductivityChatbot
        visible={chatbotVisible}
        onClose={() => setChatbotVisible(false)}
        currentMode={selectedMode}
        completedRituals={completedCount}
        totalRituals={currentRituals.length}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 32,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: '#1f2937',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6b7280',
    fontWeight: '500',
  },
  modeSwitcher: {
    flexDirection: 'row',
    paddingHorizontal: 24,
    marginBottom: 32,
    gap: 12,
  },
  modeButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 12,
    backgroundColor: 'white',
    borderRadius: 16,
    borderWidth: 2,
    borderColor: '#e5e7eb',
    gap: 8,
  },
  modeButtonText: {
    fontSize: 14,
    fontWeight: '600',
  },
  progressCard: {
    marginHorizontal: 24,
    padding: 20,
    borderRadius: 20,
    marginBottom: 24,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  progressInfo: {
    flex: 1,
  },
  progressTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  progressSubtitle: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  progressCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  progressText: {
    fontSize: 12,
    fontWeight: '700',
  },
  progressBarContainer: {
    height: 6,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBar: {
    height: '100%',
    borderRadius: 3,
  },
  checkinContainer: {
    paddingHorizontal: 24,
    marginBottom: 32,
  },
  checkinButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 6,
  },
  checkinIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  checkinTextContainer: {
    flex: 1,
  },
  checkinTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: 'white',
    marginBottom: 4,
  },
  checkinSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: '500',
  },
  ritualSection: {
    paddingHorizontal: 24,
  },
  ritualSectionTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#1f2937',
    marginBottom: 16,
  },
  ritualCard: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#f3f4f6',
  },
  ritualCardCompleted: {
    backgroundColor: '#f8fafc',
    borderColor: '#e5e7eb',
  },
  ritualContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ritualText: {
    flex: 1,
    marginRight: 16,
  },
  ritualTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 4,
  },
  ritualTitleCompleted: {
    textDecorationLine: 'line-through',
    color: '#9ca3af',
  },
  ritualDescription: {
    fontSize: 14,
    color: '#6b7280',
    fontWeight: '500',
  },
  ritualDescriptionCompleted: {
    color: '#9ca3af',
  },
  checkbox: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: '#d1d5db',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
  },
  bottomSpacing: {
    height: 32,
  },
});