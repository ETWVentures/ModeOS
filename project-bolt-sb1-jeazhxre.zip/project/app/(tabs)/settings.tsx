import React from 'react';
import { View, Text, StyleSheet, ScrollView, SafeAreaView, TouchableOpacity } from 'react-native';
import { Bell, Moon, Palette, Info } from 'lucide-react-native';

export default function SettingsScreen() {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Settings</Text>
          <Text style={styles.headerSubtitle}>Customize your ModeOS experience</Text>
        </View>

        {/* Settings Sections */}
        <View style={styles.settingsContainer}>
          <View style={styles.settingsSection}>
            <Text style={styles.sectionTitle}>Preferences</Text>
            
            <TouchableOpacity style={styles.settingsItem}>
              <View style={styles.settingsItemLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#eff6ff' }]}>
                  <Bell size={20} color="#3b82f6" />
                </View>
                <View>
                  <Text style={styles.settingsItemTitle}>Notifications</Text>
                  <Text style={styles.settingsItemSubtitle}>Manage reminder settings</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.settingsItem}>
              <View style={styles.settingsItemLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#f3e8ff' }]}>
                  <Moon size={20} color="#7c3aed" />
                </View>
                <View>
                  <Text style={styles.settingsItemTitle}>Dark Mode</Text>
                  <Text style={styles.settingsItemSubtitle}>Switch to dark theme</Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.settingsItem}>
              <View style={styles.settingsItemLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#ecfdf5' }]}>
                  <Palette size={20} color="#10b981" />
                </View>
                <View>
                  <Text style={styles.settingsItemTitle}>Themes</Text>
                  <Text style={styles.settingsItemSubtitle}>Customize mode colors</Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>

          <View style={styles.settingsSection}>
            <Text style={styles.sectionTitle}>About</Text>
            
            <TouchableOpacity style={styles.settingsItem}>
              <View style={styles.settingsItemLeft}>
                <View style={[styles.iconContainer, { backgroundColor: '#fef3c7' }]}>
                  <Info size={20} color="#f59e0b" />
                </View>
                <View>
                  <Text style={styles.settingsItemTitle}>App Info</Text>
                  <Text style={styles.settingsItemSubtitle}>Version 1.0.0</Text>
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* App Description */}
        <View style={styles.descriptionContainer}>
          <Text style={styles.descriptionTitle}>About ModeOS</Text>
          <Text style={styles.descriptionText}>
            ModeOS helps you maintain focus and build healthy habits by organizing your daily rituals 
            into different modes. Switch between Exam, Health, and Social modes to keep track of what 
            matters most in each area of your life.
          </Text>
        </View>

        <View style={styles.bottomSpacing} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    paddingHorizontal: 24,
    paddingTop: 20,
    paddingBottom: 32,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 32,
    fontWeight: '800',
    color: '#1f2937',
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 16,
    color: '#6b7280',
    fontWeight: '500',
  },
  settingsContainer: {
    paddingHorizontal: 24,
  },
  settingsSection: {
    marginBottom: 32,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1f2937',
    marginBottom: 16,
  },
  settingsItem: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.03,
    shadowRadius: 4,
    elevation: 1,
  },
  settingsItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  iconContainer: {
    width: 40,
    height: 40,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  settingsItemTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 2,
  },
  settingsItemSubtitle: {
    fontSize: 14,
    color: '#6b7280',
  },
  descriptionContainer: {
    paddingHorizontal: 24,
    marginTop: 16,
  },
  descriptionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#1f2937',
    marginBottom: 12,
  },
  descriptionText: {
    fontSize: 15,
    color: '#6b7280',
    lineHeight: 22,
    fontWeight: '500',
  },
  bottomSpacing: {
    height: 32,
  },
});