import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from 'react-native';
import { Send, Bot, User, X, Sparkles } from 'lucide-react-native';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

interface ProductivityChatbotProps {
  visible: boolean;
  onClose: () => void;
  currentMode: 'exam' | 'health' | 'social';
  completedRituals: number;
  totalRituals: number;
}

const modeContexts = {
  exam: {
    greeting: "Hey there, study warrior! 📚 Ready to tackle your academic goals?",
    color: '#3b82f6',
    bgColor: '#eff6ff',
    suggestions: [
      "How can I stay focused while studying?",
      "What's a good study break routine?",
      "Help me plan my study schedule",
    ],
  },
  health: {
    greeting: "Hello, wellness champion! 💪 Let's boost your health journey!",
    color: '#10b981',
    bgColor: '#ecfdf5',
    suggestions: [
      "What's a quick energizing workout?",
      "How can I build healthy habits?",
      "Give me motivation to exercise",
    ],
  },
  social: {
    greeting: "Hi there, social butterfly! 🌟 Ready to strengthen your connections?",
    color: '#f59e0b',
    bgColor: '#fffbeb',
    suggestions: [
      "How can I be more social today?",
      "Ideas for connecting with friends",
      "Help me plan a social activity",
    ],
  },
};

const generateResponse = (message: string, mode: 'exam' | 'health' | 'social', completedRituals: number, totalRituals: number): string => {
  const progressPercent = Math.round((completedRituals / totalRituals) * 100);
  
  // Context-aware responses based on mode and progress
  const responses = {
    exam: [
      `Great question! With ${progressPercent}% of your study rituals complete, you're making solid progress. Here's what I suggest: Break your study sessions into 25-minute focused blocks with 5-minute breaks. This Pomodoro technique helps maintain concentration while preventing burnout.`,
      `I see you've completed ${completedRituals} out of ${totalRituals} study rituals today! For better focus, try the "two-minute rule" - if a study task takes less than 2 minutes, do it immediately. For longer tasks, break them into smaller, manageable chunks.`,
      `With your current study momentum (${progressPercent}% complete), let's optimize your learning. Try active recall - test yourself on what you've learned instead of just re-reading notes. This strengthens memory retention significantly.`,
    ],
    health: [
      `Awesome! You've completed ${completedRituals} health rituals today. Remember, consistency beats intensity. Even a 10-minute walk or 5 minutes of stretching can boost your energy and mood. Small actions compound into big results!`,
      `I love your commitment to wellness! At ${progressPercent}% completion, you're building great habits. Try the "habit stacking" technique - attach new healthy behaviors to existing routines. Like doing 10 squats after brushing your teeth.`,
      `Your health journey is ${progressPercent}% on track today! Here's a pro tip: Focus on how exercise makes you FEEL rather than just the physical benefits. Notice the energy boost, better mood, and clearer thinking that follows.`,
    ],
    social: [
      `You're ${progressPercent}% through your social rituals - fantastic! Remember, meaningful connections don't require grand gestures. A simple "thinking of you" text or a genuine compliment can brighten someone's entire day.`,
      `With ${completedRituals} social rituals completed, you're nurturing your relationships beautifully! Try the "5-minute favor" concept - do something helpful for someone that takes you less than 5 minutes but provides them significant value.`,
      `Your social progress is at ${progressPercent}%! Here's something powerful: Practice active listening. Put away distractions, make eye contact, and ask follow-up questions. People remember how you made them feel more than what you said.`,
    ],
  };

  const modeResponses = responses[mode];
  return modeResponses[Math.floor(Math.random() * modeResponses.length)];
};

export default function ProductivityChatbot({
  visible,
  onClose,
  currentMode,
  completedRituals,
  totalRituals,
}: ProductivityChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  const slideAnim = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const modeContext = modeContexts[currentMode];

  useEffect(() => {
    if (visible) {
      // Initialize with greeting message
      const greeting: Message = {
        id: '1',
        text: modeContext.greeting,
        isUser: false,
        timestamp: new Date(),
      };
      setMessages([greeting]);

      // Animate in
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      // Animate out
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 250,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 0,
          duration: 250,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible, currentMode]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: text.trim(),
      isUser: true,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: generateResponse(text, currentMode, completedRituals, totalRituals),
        isUser: false,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSuggestionPress = (suggestion: string) => {
    sendMessage(suggestion);
  };

  if (!visible) return null;

  return (
    <KeyboardAvoidingView
      style={styles.overlay}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <Animated.View
        style={[
          styles.container,
          {
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [600, 0],
                }),
              },
            ],
            opacity: fadeAnim,
          },
        ]}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: modeContext.color }]}>
          <View style={styles.headerLeft}>
            <View style={styles.botIconContainer}>
              <Sparkles size={20} color="white" />
            </View>
            <View>
              <Text style={styles.headerTitle}>Productivity Coach</Text>
              <Text style={styles.headerSubtitle}>
                {currentMode.charAt(0).toUpperCase() + currentMode.slice(1)} Mode
              </Text>
            </View>
          </View>
          <TouchableOpacity onPress={onClose} style={styles.closeButton}>
            <X size={24} color="white" />
          </TouchableOpacity>
        </View>

        {/* Messages */}
        <ScrollView
          ref={scrollViewRef}
          style={styles.messagesContainer}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
        >
          {messages.map((message) => (
            <View
              key={message.id}
              style={[
                styles.messageContainer,
                message.isUser ? styles.userMessageContainer : styles.botMessageContainer,
              ]}
            >
              {!message.isUser && (
                <View style={[styles.messageIcon, { backgroundColor: modeContext.bgColor }]}>
                  <Bot size={16} color={modeContext.color} />
                </View>
              )}
              <View
                style={[
                  styles.messageBubble,
                  message.isUser
                    ? [styles.userMessage, { backgroundColor: modeContext.color }]
                    : styles.botMessage,
                ]}
              >
                <Text
                  style={[
                    styles.messageText,
                    message.isUser ? styles.userMessageText : styles.botMessageText,
                  ]}
                >
                  {message.text}
                </Text>
              </View>
              {message.isUser && (
                <View style={[styles.messageIcon, { backgroundColor: modeContext.color }]}>
                  <User size={16} color="white" />
                </View>
              )}
            </View>
          ))}

          {isTyping && (
            <View style={styles.typingContainer}>
              <View style={[styles.messageIcon, { backgroundColor: modeContext.bgColor }]}>
                <Bot size={16} color={modeContext.color} />
              </View>
              <View style={styles.typingBubble}>
                <Text style={styles.typingText}>Thinking...</Text>
              </View>
            </View>
          )}

          {/* Suggestions */}
          {messages.length === 1 && (
            <View style={styles.suggestionsContainer}>
              <Text style={styles.suggestionsTitle}>Try asking:</Text>
              {modeContext.suggestions.map((suggestion, index) => (
                <TouchableOpacity
                  key={index}
                  style={[styles.suggestionButton, { borderColor: modeContext.color }]}
                  onPress={() => handleSuggestionPress(suggestion)}
                >
                  <Text style={[styles.suggestionText, { color: modeContext.color }]}>
                    {suggestion}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </ScrollView>

        {/* Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Ask me anything about productivity..."
            placeholderTextColor="#9ca3af"
            multiline
            maxLength={500}
          />
          <TouchableOpacity
            style={[
              styles.sendButton,
              { backgroundColor: inputText.trim() ? modeContext.color : '#e5e7eb' },
            ]}
            onPress={() => sendMessage(inputText)}
            disabled={!inputText.trim() || isTyping}
          >
            <Send size={20} color={inputText.trim() ? 'white' : '#9ca3af'} />
          </TouchableOpacity>
        </View>
      </Animated.View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: 1000,
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
    marginTop: 60,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    overflow: 'hidden',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    paddingTop: 24,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  botIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: 'white',
  },
  headerSubtitle: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
    fontWeight: '500',
  },
  closeButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  messagesContainer: {
    flex: 1,
    padding: 16,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 16,
    alignItems: 'flex-end',
  },
  userMessageContainer: {
    justifyContent: 'flex-end',
  },
  botMessageContainer: {
    justifyContent: 'flex-start',
  },
  messageIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 8,
  },
  messageBubble: {
    maxWidth: '75%',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
  },
  userMessage: {
    borderBottomRightRadius: 6,
  },
  botMessage: {
    backgroundColor: '#f3f4f6',
    borderBottomLeftRadius: 6,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 22,
  },
  userMessageText: {
    color: 'white',
    fontWeight: '500',
  },
  botMessageText: {
    color: '#1f2937',
    fontWeight: '500',
  },
  typingContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  typingBubble: {
    backgroundColor: '#f3f4f6',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 20,
    borderBottomLeftRadius: 6,
  },
  typingText: {
    fontSize: 16,
    color: '#6b7280',
    fontStyle: 'italic',
  },
  suggestionsContainer: {
    marginTop: 16,
    paddingHorizontal: 8,
  },
  suggestionsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#6b7280',
    marginBottom: 12,
  },
  suggestionButton: {
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 8,
    backgroundColor: 'white',
  },
  suggestionText: {
    fontSize: 14,
    fontWeight: '500',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: '#f3f4f6',
    backgroundColor: 'white',
  },
  textInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#e5e7eb',
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    maxHeight: 100,
    marginRight: 12,
    backgroundColor: '#f9fafb',
  },
  sendButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
});